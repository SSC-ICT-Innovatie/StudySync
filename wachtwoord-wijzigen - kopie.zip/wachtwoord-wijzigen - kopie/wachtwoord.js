document.getElementById("changePasswordButton").addEventListener("click", function() {
    var currentPassword = document.getElementById("currentPassword").value;
    var newPassword = document.getElementById("newPassword").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    if (newPassword === confirmPassword) {
        if (newPassword !== currentPassword) {
            // Hier maak je een AJAX-verzoek naar de server om het wachtwoord te wijzigen.
            var xhr = new XMLHttpRequest();
            var url = "changepassword.php";
            var params = "currentPassword=" + currentPassword + "&newPassword=" + newPassword;

            xhr.open("POST", url, true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var response = xhr.responseText;
                    document.getElementById("message").textContent = response;
                    if (response === "Wachtwoord succesvol gewijzigd!") {
                        // Voer hier aanvullende acties uit na een succesvolle wijziging
                        // Bijvoorbeeld: de gebruiker uitloggen, doorverwijzen, etc.
                    }
                }
            };

            xhr.send(params);
        } else {
            document.getElementById("message").textContent = "Nieuw wachtwoord mag niet hetzelfde zijn als het huidige wachtwoord.";
        }
    } else {
        document.getElementById("message").textContent = "Herhaald wachtwoord komt niet overeen met het nieuwe wachtwoord.";
    }
});





