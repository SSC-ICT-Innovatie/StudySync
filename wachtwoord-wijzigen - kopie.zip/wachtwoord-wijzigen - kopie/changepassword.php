<?php
// Databaseverbinding instellen
$servername = "jouw_servernaam"; // Vervang dit door de naam van je MySQL-server
$username = "jouw_gebruikersnaam"; // Vervang dit door je MySQL-gebruikersnaam
$password = "jouw_wachtwoord"; // Vervang dit door je MySQL-wachtwoord
$dbname = "jouw_database"; // Vervang dit door de naam van je database

// Een verbinding maken met de database
$conn = new mysqli($servername, $username, $password, $dbname);

// Controleren op fouten in de verbinding
if ($conn->connect_error) {
    die("Verbinding met de database is mislukt: " . $conn->connect_error);
}

// Gegevens van het POST-verzoek ophalen
$currentPassword = $_POST["currentPassword"];
$newPassword = $_POST["newPassword"];

// Voer hier eventuele extra beveiligingscontroles uit voordat je de query uitvoert

// Voer een query uit om het wachtwoord van de gebruiker in de database bij te werken
// Hier ga ik ervan uit dat je een gebruikerstabel hebt met de kolomnamen 'gebruikersnaam' en 'wachtwoord'
$sql = "UPDATE gebruikerstabel SET wachtwoord = ? WHERE gebruikersnaam = ?";

if ($stmt = $conn->prepare($sql)) {
    // Het wachtwoord hashen voordat we het opslaan in de database
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt->bind_param("ss", $hashedPassword, $gebruikersnaam); // Vervang 'gebruikersnaam' door de juiste kolomnaam

    // De gebruikersnaam invullen met de juiste waarde
    $gebruikersnaam = "jouw_gebruikersnaam"; // Vervang dit door de gebruikersnaam van de gebruiker

    if ($stmt->execute()) {
        echo "Wachtwoord succesvol gewijzigd!";
    } else {
        echo "Fout bij het wijzigen van het wachtwoord: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Fout bij de voorbereiding van de query: " . $conn->error;
}

// Verbinding met de database sluiten
$conn->close();
?>

